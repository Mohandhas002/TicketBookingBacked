package com.rest.ticketbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTicketBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
