package com.rest.ticketbooking.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.ticketbooking.dao.TicketBookingDAO;
import com.rest.ticketbooking.entities.Ticket;
@Service
public class TicketBookingServices {
	@Autowired
	private TicketBookingDAO ticketBookingDAO;
	
	
	public Ticket createTicket(Ticket ticket) {
		return ticketBookingDAO.save(ticket);
	}
	
	
	public Ticket getTicketById(Integer ticket_id) {
		return ticketBookingDAO.findById(ticket_id).get();
	}

	
	public Iterable<Ticket> getAllTickets(){
		
		return ticketBookingDAO.findAll();
	}
	
	

	public void deleteTicketById(Integer ticket_id) {
		
		ticketBookingDAO.deleteById(ticket_id);
	} 
	

	public Ticket updateTicketById(Integer ticket_Id,String email) {
		Ticket newTicket = ticketBookingDAO.findById(ticket_Id).get();
		newTicket.setEmail(email);
		Ticket tc=ticketBookingDAO.save(newTicket);
		return tc;
	}

}
