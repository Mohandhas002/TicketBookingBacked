package com.rest.ticketbooking.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="Ticket")
@Data
@AllArgsConstructor  
@NoArgsConstructor   
public class Ticket {
	@Id
	@Column(name="Ticket_id")
	private Integer ticket_id;
	
	@Column(name="Passenger_name")
	private String passengerName;
	
	@Column(name="Source_Station")
	private String sourceStation;
	
	@Column(name="Destination")
	private String destination;
	
	@Column(name="Email")
	private String email;

//	public void setEmail(String email2) {
//	     email = email2;
//	}
	

}
