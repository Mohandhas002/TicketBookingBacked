package com.rest.ticketbooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rest.ticketbooking.entities.Ticket;
import com.rest.ticketbooking.services.TicketBookingServices;
@RestController
@RequestMapping(value="/api/tickets")
public class TicketBookingController {
	@Autowired
     private TicketBookingServices ticketBookingServices;
     
	@PostMapping(value="/createticket")
	public Ticket createTicket(@RequestBody Ticket ticket) {
		return ticketBookingServices.createTicket(ticket);
	}
	
   @GetMapping(value="/gettickets/{Ticket_id}")
	public Ticket getTicketById(@PathVariable("Ticket_id")Integer ticket_id) {
		return ticketBookingServices.getTicketById(ticket_id);
	}
	
	@GetMapping(value="/alltickets")
	public Iterable<Ticket> getAllTickets(){
		
		return ticketBookingServices.getAllTickets();
	}
	
	
	@DeleteMapping(value="/delete/{Ticket_id}")
	public void deleteTicketById(@PathVariable("Ticket_id")Integer ticket_id) {
		
		ticketBookingServices.deleteTicketById(ticket_id);
	} 
	
    @PostMapping(value="/updateticket/{Ticket_id}/{newEmail:.+}")
	public Ticket updateTicketById(@PathVariable("Ticket_id")Integer ticket_id,@PathVariable("newEmail") String email) {
		return ticketBookingServices.updateTicketById(ticket_id, email);
	}
}
