package com.rest.ticketbooking.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rest.ticketbooking.entities.Ticket;

public interface TicketBookingDAO extends JpaRepository<Ticket,Integer > {

}
